from flask import Flask, jsonify
import os
import re
import pdfplumber
from docx import Document

from flask import Blueprint, jsonify
import os

scoring_bp = Blueprint('scoring_bp', __name__)

app = Flask(__name__)

# --- Configuration ---
BASE_DIR = 'app'
JD_FOLDER = os.path.join(BASE_DIR, 'jdfolder')
RESUME_FOLDER = os.path.join(BASE_DIR, 'resumes')

sap_skills = ["General Ledger", "Accounts Payable", "S/4HANA", "SAP Security", "Authorization", "PFCG", "GRC", "Fiori", "BAPI", "MM", "SD", "FI", "CO"]

# --- Utility Functions ---
def clean_text(text):
    return re.sub(r'[^a-zA-Z0-9\s]', '', text.lower())

def extract_keywords(text, keyword_list):
    text = clean_text(text)
    return [kw for kw in keyword_list if kw.lower() in text]

def count_certifications(text):
    lines = text.splitlines()
    cert_count = 0
    capture = False
    for line in lines:
        lower = line.lower().strip()
        if "certifications" in lower or "certification" in lower:
            capture = True
            continue
        if capture:
            if lower.strip() == "" or re.match(r'^[A-Z][a-z]+:?', line):
                break
            if re.match(r'[-•*]\s', line.strip()) or len(line.strip()) > 5:
                cert_count += 1
    return cert_count

def count_projects(text):
    lines = text.splitlines()
    proj_count = 0
    capture = False
    for line in lines:
        lower = line.lower().strip()
        if "projects" in lower or "project experience" in lower:
            capture = True
            continue
        if capture:
            if lower.strip() == "" or re.match(r'^[A-Z][a-z]+:?', line):
                break
            if re.match(r'[-•*]\s', line.strip()) or re.search(r'\b(project\s)?on\b', line.lower()):
                proj_count += 1
    return proj_count

def extract_experience_years(text):
    match = re.search(r'(\d{1,2})\+?\s+(years|yrs)\s+(of\s+)?experience', text.lower())
    return int(match.group(1)) if match else 0

def calculate_score(matched_skills, jd_skills, certs, projects, exp):
    skill_score = len(matched_skills) / len(jd_skills) * 40 if jd_skills else 0
    cert_score = min(certs, 5) * 4  # Max 20
    proj_score = min(projects, 5) * 4  # Max 20
    exp_score = min(exp, 10) * 2     # Max 20
    total_score = skill_score + cert_score + proj_score + exp_score
    return round(total_score, 2)

def read_file(path):
    if path.endswith('.txt'):
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    elif path.endswith('.pdf'):
        with pdfplumber.open(path) as pdf:
            return '\n'.join(page.extract_text() for page in pdf.pages if page.extract_text())
    elif path.endswith('.docx'):
        doc = Document(path)
        return '\n'.join([para.text for para in doc.paragraphs])
    else:
        return ''

# --- Flask Route ---
@scoring_bp.route('/score', methods=['GET'])
def process_folder():
    jd_files = [f for f in os.listdir(JD_FOLDER) if f.endswith(('.pdf', '.docx', '.txt'))]
    if not jd_files:
        return jsonify({"error": "No JD file found in jdfolder"}), 404

    jd_path = os.path.join(JD_FOLDER, jd_files[0])
    jd_text = read_file(jd_path)
    jd_skills = extract_keywords(jd_text, sap_skills)

    results = []
    for filename in os.listdir(RESUME_FOLDER):
        filepath = os.path.join(RESUME_FOLDER, filename)
        if not os.path.isfile(filepath) or not filepath.endswith(('.pdf', '.docx', '.txt')):
            continue

        resume_text = read_file(filepath)
        resume_skills = extract_keywords(resume_text, jd_skills)
        certs = count_certifications(resume_text)
        projects = count_projects(resume_text)
        exp_years = extract_experience_years(resume_text)
        score = calculate_score(resume_skills, jd_skills, certs, projects, exp_years)

        results.append({
            'Resume': filename,
            'Matched Skills': resume_skills,
            'Certifications': certs,
            'Projects': projects,
            'Experience (Years)': exp_years,
            'Score': score
        })

    return jsonify({
        "JD File": jd_files[0],
        "JD Skills": jd_skills,
        "Results": results
    })

# --- Run App ---
if __name__ == '__main__':
    app.run(debug=True)
