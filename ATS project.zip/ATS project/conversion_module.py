from flask import Blueprint, request, jsonify
import os
import re
from docx import Document
import fitz  # PyMuPDF

conversion_bp = Blueprint('conversion_bp', __name__)
UPLOAD_FOLDER = 'temp_uploads'
JD_FOLDER = 'app/jdfolder'
RESUME_FOLDER = 'app/resumes'
ALLOWED_EXTENSIONS = {"pdf", "docx", "txt"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(JD_FOLDER, exist_ok=True)
os.makedirs(RESUME_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text(file_storage):
    filename = file_storage.filename
    ext = os.path.splitext(filename)[1].lower()

    if ext == '.pdf':
        # Read PDF directly from memory
        file_bytes = file_storage.read()
        with fitz.open("pdf", file_bytes) as doc:
            return "\n".join([page.get_text() for page in doc])
    elif ext == '.docx':
        doc = Document(file_storage)
        return "\n".join([para.text for para in doc.paragraphs])
    elif ext == '.txt':
        return file_storage.read().decode('utf-8')
    return ""
def extract_section_items(text, section_keywords):
    lines = text.split('\n')
    items = []
    collecting = False

    for line in lines:
        line_strip = line.strip()
        if any(re.match(rf"^{keyword}\b", line_strip, re.IGNORECASE) for keyword in section_keywords):
            collecting = True
            continue
        if collecting and re.match(r'^[A-Z][A-Za-z\s]+$', line_strip) and len(line_strip.split()) <= 5:
            break
        if collecting:
            if line_strip:
                if not re.match(r"^[-•*]", line_strip):
                    items.append(f"- {line_strip}")
                else:
                    items.append(line_strip)
    return items

def format_resume(text):
    text = text.replace('\r\n', '\n').replace('\r', '\n')

    certs = extract_section_items(text, ["certifications", "certification"])
    projects = extract_section_items(text, ["projects", "project experience", "Professional Experience"])
    education = extract_section_items(text, ["Education", "academic background"])
    skills = extract_section_items(text, ["skills", "technical skills"])

    formatted_resume = "=== Certifications ===\n"
    formatted_resume += "\n".join(certs) if certs else "No certifications found."
    formatted_resume += "\n\n=== Projects Done ===\n"
    formatted_resume += "\n".join(projects) if projects else "No projects found."
    formatted_resume += "\n\n=== Education ===\n"
    formatted_resume += "\n".join(education) if education else "No education info found."
    formatted_resume += "\n\n=== Skills ===\n"
    formatted_resume += "\n".join(skills) if skills else "No skills found."

    return formatted_resume


@conversion_bp.route('/upload', methods=['POST'])
def upload():
    jd_file = request.files.get("jd")
    resumes = request.files.getlist("resumes")

    if not jd_file or not resumes:
        return jsonify({"error": "Both JD and resumes are required"}), 400
    
    # Process JD
    jd_text = extract_text(jd_file)
    jd_text = format_resume(jd_text)
    jd_filename = os.path.splitext(jd_file.filename)[0] + "_formatted.txt"
    jd_path = os.path.join(JD_FOLDER, jd_filename)
    with open(jd_path, "w", encoding="utf-8") as f:
        f.write(jd_text)
    # Process Resumes
    saved_files = []
    for resume in resumes:
        resume_text = extract_text(resume)
        resume_text = format_resume(resume_text)
        formatted_name = os.path.splitext(resume.filename)[0] + "_formatted.txt"
        formatted_path = os.path.join(RESUME_FOLDER, formatted_name)
        with open(formatted_path, "w", encoding="utf-8") as f:
            f.write(resume_text)
        saved_files.append(formatted_name)

    return jsonify({
        "message": "Files formatted and saved",
        "jd_file": jd_filename,
        "resumes": saved_files
    })